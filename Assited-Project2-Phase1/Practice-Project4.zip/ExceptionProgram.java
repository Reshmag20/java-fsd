package assistedPractice;

public class ExceptionProgram {
	public static void main(String[] args) {
		//ArithmeticException
		try
		{
		int a=10,b=0;
		int c;
		c=a/b;
		}catch(ArithmeticException e){
		System.out.println("Arithmetic Exception has occured");
		}
		//NullPointerException
		try{
			int arr[]=null;
			System.out.println(arr[1]);
		}catch(NullPointerException e) {
			System.out.println("null poiter exception has occured");
		}
	}
}
