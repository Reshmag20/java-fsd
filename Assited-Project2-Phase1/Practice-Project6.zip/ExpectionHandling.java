package assistedPractice;
public class ExpectionHandling {
    public static void main(String[] args) {
        try {
            
            int result = divide(10, 0);
            System.out.println("Result: " + result); //
        } catch (ArithmeticException e) {
            
            System.out.println("ArithmeticException: " + e.getMessage());
        } catch (Exception e) {
            
            System.out.println("Exception: " + e.getMessage());
        } finally {
            
            System.out.println("Finally block executed.");
        }

        System.out.println("Program continues after handling the exception.");
    }

    public static int divide(int dividend, int divisor) {
        return dividend / divisor;
    }
}