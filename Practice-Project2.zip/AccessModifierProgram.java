package assistedPractice;

public class AccessModifierProgram{
	//Public
	public static void m1() {
		System.out.println("public modifier ");
	}
	//protected
	protected static void m2() {
		System.out.println("protected modifier ");
	}
	//private
	private static void m3() {
		System.out.println("private modifier");
	}
	//default
	static void m4() {
		System.out.println("default access modifer");
	}
	public static void main(String[] args){
		AccessModifierProgram.m1();
		AccessModifierProgram.m2();
		AccessModifierProgram.m3();
		AccessModifierProgram.m4();
	  
		}
	}