package com.pack;

import java.util.LinkedList;
import java.util.Queue;

public class ProgramNine {
    public static void main(String[] args) {
        // Create a queue
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.offer(7);
        queue.offer(9);
        queue.offer(11);
        queue.offer(13);

        System.out.println("Queue elements after enqueuing:");
        System.out.println(queue);

        // Dequeue an element from the queue
        int dequeuedElement = queue.poll();
        int dequeuedElement2 = queue.poll();
        System.out.println("Dequeued Element: " + dequeuedElement);
        System.out.println("Dequeued Element: " + dequeuedElement2);

        System.out.println("Queue elements after dequeuing:");
        System.out.println(queue);
    }
}