package com.pack;
public class Programone {
    public static void rightRotate(int[] arr, int steps) {
        int length = arr.length;
        if (length == 0) {
            return;
        }

        steps = steps % length;

        int[] rotatedArr = new int[length];

        for (int i = 0; i < length; i++) {
            int newPosition = (i + steps) % length;
            rotatedArr[newPosition] = arr[i];
        }

        System.arraycopy(rotatedArr, 0, arr, 0, length);
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7};
        int steps = 3;

        System.out.println("Original Array:");
        printArray(arr);

        rightRotate(arr, steps);

        System.out.println("Array after right rotation by " + steps + " steps:");
        printArray(arr);
    }

    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}