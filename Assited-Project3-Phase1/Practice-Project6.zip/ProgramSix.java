package com.pack;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    private Node head;

    SortedCircularLinkedList() {
        head = null;
    }

    void insert(int newData) {
        Node newNode = new Node(newData);
        
        if (head == null) {
            head = newNode;
            head.next = head; // Point to itself in a circular manner
        } else if (newNode.data < head.data) {
            // If the new data is smaller than the head data, insert before the head
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Find the correct position to insert while keeping the list sorted
            Node current = head;
            while (current.next != head && current.next.data < newNode.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class ProgramSix {
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        list.insert(51);
        list.insert(24);
        list.insert(78);
        list.insert(11);

        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}
