package com.pack;
import java.util.Arrays;
public class ProgramTwo {
    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            throw new IllegalArgumentException("Array should have at least four elements");
        }

        Arrays.sort(arr); // Sort the array in ascending order.
        
        // The fourth smallest element will be at index 3 (0-based index).
        return arr[3];
    }

    public static void main(String[] args) {
        int[] arr = {78,9,45,64,99,34,12,80};
        int fourthSmallest = findFourthSmallest(arr);
        
        System.out.println("Original Array: " + Arrays.toString(arr));
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }
}