package assistedPractice;
class TypesOfConstructor{
	int empId;
	String employee_Name;
	static String company_name="xyz";
	//no argument constructor
	public  TypesOfConstructor() {
		System.out.println("No Argument constructor completed");
	}
	//parameterized constructor
	public  TypesOfConstructor(int empId,String employee_Name) {
		System.out.println(this.empId=empId);
		System.out.println(this.employee_Name=employee_Name);
		System.out.println(this.company_name=company_name);
	}
}
public class TypesOfConstructors{
  public static void main(String[] args) {
	  TypesOfConstructor t1=new  TypesOfConstructor();
	  TypesOfConstructor t2=new  TypesOfConstructor(01,"Vijay");
}
  
}