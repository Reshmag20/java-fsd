package assistedPractice;
public class StringBufferAndBuilder {

	public static void main(String[] args) {
		//methods of strings
		String s1="thankyou";
		String s2="thanku";
		String s3="";
		String s4="String";
		String sl=new String("methods of string");
		System.out.println(sl.length());
		String sub=new String("string");
		System.out.println(sub.substring(2));
		System.out.println(s1.compareTo(s2));
		System.out.println(s3.isEmpty());
		System.out.println(s1.toLowerCase());
		String replace=s2.replace('h', 'n');
		System.out.println(replace);
		String x="equals method";
		String y="Equals method";
		System.out.println(x.equals(y));
		System.out.println("Creation of StringBuffer");
		//StringBuffer and append method
		StringBuffer s=new StringBuffer("welcome to tutorial");
		s.append("Enjoy your class");
		System.out.println(s);
		s.insert(0, 'w');
		System.out.println(s);
		StringBuffer sb=new StringBuffer("Hello");
		sb.replace(0, 2, "hEl");
		System.out.println(sb);
		sb.delete(0, 1);
		System.out.println(sb);
		//StringBuilder
		System.out.println("\n");
		System.out.println("Creation of StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);
        System.out.println(sb1.delete(0, 2));
		System.out.println(sb1.insert(1, "Welcome"));
		System.out.println(sb1.reverse());
		String str = "Hello";    
        // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		
	}
}


