package assistedPractice;

public class TypeCastingProgram {
	public static void main(String[] args) {
		//implicit TypeCasting
	byte b=20;
	short s=b;
	int i=s;
	long l=i;
	float f=l;
	double d=f;
	System.out.println("Byte:" + b);
    System.out.println("Short:" + s);
    System.out.println("int:" + i);
    System.out.println("long:" + l);
    System.out.println("float:" + f);
    System.out.println("double:" + d);
	//explicit TypeCasting
    int a=(int)100.123;
    char b1=(char)65.45;
    double c=(double)10;
	System.out.println("integer "+a);
	System.out.println("char:" + b1);
	System.out.println("double:" + c);
}


}
