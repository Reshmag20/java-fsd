package assistedPractice;

public class MethodProgram {
	public static void main(String[] args) {
		MethodProgram m1=new MethodProgram();
	m1.method1();
	int sub=m1.add(20,2 );

	System.out.println(sub);
	m1.method2("Method with a parameter and no return type");
	}
	void method1() {
	 System.out.println("Method with no argument and no return type");
 }
	int add(int a,int b) {
	 return a-b;
	}
	void method2(String Statement) {
	 System.out.println(Statement);
 }
 
}
